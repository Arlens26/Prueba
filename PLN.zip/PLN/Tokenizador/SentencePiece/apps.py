from django.apps import AppConfig


class SentencepieceConfig(AppConfig):
    name = 'SentencePiece'
